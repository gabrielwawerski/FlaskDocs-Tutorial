import sqlite3

import click
from flask import current_app, g
from flask.cli import with_appcontext
from sqlalchemy import Table, Column, Integer, String, MetaData, ForeignKey, create_engine
import datetime


def init_db():
    db = get_db()
    with current_app.open_resource('schema.sql') as f:
        db.executescript(f.read().decode('utf8'))


def init_db_engine():
    engine = get_engine()
    metadata = MetaData()
    g.users = Table('user', metadata,
                    Column('id', Integer, primary_key=True, autoincrement=True),
                    Column('username', String, unique=True),
                    Column('password', String),
                    Column('name', String),
                    Column('surname', String),
                    Column('age', Integer)
                    )
    g.posts = Table('post', metadata,
                    Column('id', Integer, primary_key=True, autoincrement=True),
                    Column('author_id', Integer, ForeignKey('user.id')),
                    Column('comment_id', Integer, ForeignKey('comment.id')),
                    Column('created', String, str(datetime.datetime.now().timestamp())),
                    Column('title', String),
                    Column('post', String)
                    )
    g.comments = Table('comment', metadata,
                       Column('id', Integer, primary_key=True, autoincrement=True),
                       Column('author_id', Integer, ForeignKey('user.id')),
                       Column('post_id', Integer, ForeignKey('post.id')),
                       Column('comment', String),
                       Column('created', String, str(datetime.datetime.now().timestamp())),
                       )
    metadata.create_all(engine)


@click.command('init-db')
@with_appcontext
def init_db_command():
    """Clear existing data, create new tables."""
    init_db()
    click.echo('Database initialized.')


def init_app(app):
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)


def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(
            current_app.config['DATABASE'],
            detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row
    return g.db


def get_engine():
    if 'engine' not in g:
        g.engine = create_engine('sqlite+pysqlite:///instance/flaskr.sqlite', echo=True)
        print(g.engine)
    return g.engine


def close_db(e=None):
    db = g.pop('db', None)

    if db is not None:
        db.close()
