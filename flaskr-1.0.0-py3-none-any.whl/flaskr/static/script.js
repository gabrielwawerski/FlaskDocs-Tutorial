function clearData() {
    console.log("Hello World! clearData");
    let commentArea = document.getElementById("comment");
    commentArea.innerText = "";
}
